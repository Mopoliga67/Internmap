import csv
import time
import requests
import urllib.parse

def main():
    # Définition des fichiers d'entrée et de sortie
    input_file = r'c:\projet\Data\stages_pret_pour_supabase.csv'
    output_file = r'c:\projet\Data\stage_pret_pour_supabase_geocoded.csv'

    with open(input_file, mode='r', encoding='utf-8') as f_in, \
         open(output_file, mode='w', encoding='utf-8', newline='') as f_out:

        reader = csv.DictReader(f_in)
        fieldnames = reader.fieldnames
        writer = csv.DictWriter(f_out, fieldnames=fieldnames)
        writer.writeheader()

        count = 0
        for row in reader:
            lat = float(row['lat']) if row['lat'] else 0.0
            lng = float(row['lng']) if row['lng'] else 0.0

            # Si les coordonnées sont manquantes, on les cherche via l'adresse
            if lat == 0.0 and lng == 0.0:
                adresse = row['adresse']
                ville = row['ville']
                query = urllib.parse.quote(f"{adresse} {ville}")
                # Requête vers l'API Adresse du gouvernement français
                url = f"https://api-adresse.data.gouv.fr/search/?q={query}&limit=1"

                try:
                    response = requests.get(url)
                    if response.status_code == 200:
                        data = response.json()
                        if data['features']:
                            # Mise à jour des coordonnées (longitude, latitude)
                            coords = data['features'][0]['geometry']['coordinates']
                            row['lng'] = coords[0]
                            row['lat'] = coords[1]
                            print(f"Géocodé : {adresse}, {ville} -> {row['lat']}, {row['lng']}")
                        else:
                            print(f"Aucun résultat pour : {adresse}, {ville}")
                    else:
                        print(f"Erreur API {response.status_code} pour : {adresse}, {ville}")
                except Exception as e:
                    print(f"Erreur lors de la requête pour {adresse}, {ville}: {e}")

                # Légère pause pour respecter la limite de requêtes de l'API
                time.sleep(0.1)
                count += 1

            writer.writerow(row)

    print(f"Géocodage terminé. {count} adresses traitées.")

if __name__ == '__main__':
    main()
