import asyncio
from supabase import create_client
import pandas as pd

# CONFIGURATION
SUPABASE_URL = "https://your-project.supabase.co"
SUPABASE_KEY = "votre_service_role_key" # IMPORTANT : Utilisez la clé Service Role

supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

async def update_active_companies():
    print("🔭 Analyse des offres de la semaine...")
    
    # --- PARTIE SCRAPING (Exemple) ---
    # Ici, tu places ton code qui scrape JobTeaser
    # Pour l'exemple, on imagine qu'on a trouvé ces entreprises :
    entreprises_trouvees = [
        "Capgemini France", 
        "BNP Paribas", 
        "Dassault Systemes", 
        "Societe Generale",
        "Thales"
    ]
    
    if not entreprises_trouvees:
        print("📭 Aucune offre trouvée cette semaine.")
        return

    # --- APPEL PRO (RPC) ---
    print(f"🚀 Envoi de {len(entreprises_trouvees)} mises à jour à Supabase...")
    
    try:
        # On appelle la fonction SQL 'bulk_increment_scores' qu'on a créée
        supabase.rpc(
            'bulk_increment_scores', 
            {'company_names': entreprises_trouvees}
        ).execute()
        
        print("✅ Scores incrémentés avec succès !")
        
    except Exception as e:
        print(f"💥 Erreur lors de l'appel RPC : {e}")

if __name__ == "__main__":
    asyncio.run(update_active_companies())