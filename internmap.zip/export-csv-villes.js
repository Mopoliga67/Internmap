// Génère un CSV par ville (Lyon, Marseille, Toulouse) à partir de l'API
// recherche-entreprises.api.gouv.fr — format identique à stages_pret_pour_supabase.csv

const fs = require("fs");
const path = require("path");

const VILLES = {
  lyon: {
    nom: "LYON",
    codesPostaux: Array.from({ length: 9 }, (_, i) => `6900${i + 1}`),
  },
  marseille: {
    nom: "MARSEILLE",
    codesPostaux: Array.from({ length: 16 }, (_, i) => `130${String(i + 1).padStart(2, "0")}`),
  },
  toulouse: {
    nom: "TOULOUSE",
    codesPostaux: ["31000", "31100", "31200", "31300", "31400", "31500"],
  },
};

const NAF_DOMAINES = {
  "62": ["informatique", "tech", "développement"],
  "63": ["informatique", "tech", "data"],
  "64": ["finance", "banque", "comptabilité"],
  "65": ["finance", "assurance"],
  "66": ["finance", "conseil"],
  "70": ["conseil", "management", "stratégie"],
  "69": ["droit", "juridique", "comptabilité"],
  "71": ["architecture", "ingénierie", "btp"],
  "73": ["marketing", "communication", "publicité"],
  "78": ["rh", "recrutement"],
  "74": ["conseil", "design"],
  "58": ["médias", "édition"],
  "59": ["médias", "audiovisuel", "communication"],
  "60": ["médias", "radio", "tv"],
  "46": ["commerce", "négoce"],
  "47": ["commerce", "retail", "vente"],
  "86": ["santé", "médical"],
  "85": ["enseignement", "formation"],
  "84": ["administration", "secteur public"],
  "41": ["btp", "immobilier", "construction"],
  "68": ["immobilier"],
  "49": ["logistique", "transport"],
  "52": ["logistique", "supply chain"],
};

function getDomainesFromNaf(codeNaf) {
  if (!codeNaf) return ["autre"];
  return NAF_DOMAINES[codeNaf.substring(0, 2)] || ["autre"];
}

const TRANCHES_VALIDE = ["NN", "00", "01", "02", "03", "11", "12", "21", "22", "31", "32", "41"];

function getScoreEmbauche(tranche) {
  if (!tranche) return Math.floor(Math.random() * 4) + 1;
  switch (tranche) {
    case "NN":
    case "00":
    case "01": return 1 + Math.floor(Math.random() * 2);
    case "02":
    case "03": return 3 + Math.floor(Math.random() * 2);
    case "11":
    case "12": return 5 + Math.floor(Math.random() * 2);
    case "21":
    case "22": return 7;
    case "31":
    case "32": return 8;
    case "41": return 9 + Math.floor(Math.random() * 2);
    default: return 5;
  }
}

function csvEscape(v) {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function rowToCsv(row, columns) {
  return columns.map((c) => csvEscape(row[c])).join(",");
}

async function fetchPage(codePostal, page, retry = 0) {
  const url = `https://recherche-entreprises.api.gouv.fr/search?code_postal=${codePostal}&per_page=25&page=${page}&statut_diffusion=O`;
  const res = await fetch(url);
  if (res.status === 429 && retry < 3) {
    await new Promise((r) => setTimeout(r, 1500 * (retry + 1)));
    return fetchPage(codePostal, page, retry + 1);
  }
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function exporterVille(key, cfg) {
  console.log(`\n=== ${cfg.nom} ===`);
  const seenSirets = new Set();
  const rows = [];

  for (const cp of cfg.codesPostaux) {
    process.stdout.write(`  📍 ${cp} `);

    for (let page = 1; page <= 8; page++) {
      try {
        const data = await fetchPage(cp, page);
        const results = data.results || [];
        if (results.length === 0) break;

        let added = 0;
        for (const ent of results) {
          // Utilise l'établissement local (matching_etablissements) plutôt que le siège,
          // pour avoir l'adresse réelle dans la ville (ex: agence Société Générale à Lyon
          // au lieu de son siège parisien)
          const matching = (ent.matching_etablissements || [])[0] || ent.siege || {};
          const lat = parseFloat(matching.latitude);
          const lng = parseFloat(matching.longitude);
          if (!lat || !lng || isNaN(lat) || isNaN(lng)) continue;

          const siret = matching.siret;
          if (!siret || seenSirets.has(siret)) continue;

          // Confirme que l'établissement est bien dans la ville cible
          const commune = (matching.libelle_commune || "").toUpperCase();
          if (!commune.includes(cfg.nom)) continue;

          const tranche = matching.tranche_effectif_salarie || ent.tranche_effectif_salarie;
          if (tranche && !TRANCHES_VALIDE.includes(tranche)) continue;

          const codeNaf = matching.activite_principale || ent.activite_principale;
          const domaines = getDomainesFromNaf(codeNaf);

          seenSirets.add(siret);
          rows.push({
            nom: ent.nom_complet || ent.nom_raison_sociale || "Entreprise sans nom",
            adresse: [matching.numero_voie, matching.type_voie, matching.libelle_voie, matching.code_postal, matching.libelle_commune]
              .filter(Boolean)
              .join(" "),
            ville: cfg.nom,
            siret,
            lat,
            lng,
            domaines: JSON.stringify(domaines),
            score_embauche: getScoreEmbauche(tranche),
            source: "API_Recherche_Entreprises",
            code_naf: codeNaf || "",
            tranche_effectif: tranche || "",
          });
          added++;
        }
        process.stdout.write(`p${page}+${added} `);
        await new Promise((r) => setTimeout(r, 350));
      } catch (e) {
        process.stdout.write(`[err:${e.message}] `);
        break;
      }
    }
    process.stdout.write("\n");
  }

  const columns = [
    "nom", "adresse", "ville", "siret", "lat", "lng",
    "domaines", "score_embauche", "source", "code_naf", "tranche_effectif",
  ];
  const csv = [columns.join(",")].concat(rows.map((r) => rowToCsv(r, columns))).join("\n");

  const outDir = path.join(__dirname, "Data");
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  const outFile = path.join(outDir, `stages_${key}.csv`);
  fs.writeFileSync(outFile, csv, "utf8");

  console.log(`  ✅ ${rows.length} entreprises écrites → ${outFile}`);
  return rows.length;
}

(async () => {
  const args = process.argv.slice(2);
  const villesACibler = args.length > 0
    ? args.filter((a) => VILLES[a])
    : Object.keys(VILLES);

  let total = 0;
  for (const key of villesACibler) {
    total += await exporterVille(key, VILLES[key]);
  }
  console.log(`\n🎉 Terminé — ${total} entreprises au total sur ${villesACibler.length} ville(s).`);
})().catch((e) => {
  console.error("Erreur fatale:", e);
  process.exit(1);
});
