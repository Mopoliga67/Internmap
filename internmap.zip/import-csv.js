const { createClient } = require("@supabase/supabase-js");
const fs = require("fs");
const readline = require("readline");

// Configuration Supabase
const SUPABASE_URL = "https://kykglnfuvxcfitpmugld.supabase.co";
const SUPABASE_SERVICE_KEY = "METS_ICI_TA_SERVICE_ROLE_KEY";

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

const CSV_FILE = "./Data/stages_pret_pour_supabase.csv";
const BATCH_SIZE = 100;

function parseArray(val) {
  if (!val) return null;
  if (val.startsWith("[") && val.endsWith("]")) {
    try {
      return JSON.parse(val);
    } catch(e) {}
  }
  return val.replace(/[{}]/g, "").split(",").map(s => s.trim()).filter(s => s.length > 0);
}

async function importCSV() {
  console.log("📂 Lecture du fichier CSV...");

  const fileStream = fs.createReadStream(CSV_FILE);
  const rl = readline.createInterface({ input: fileStream, crlfDelay: Infinity });

  let headers = null;
  let rows = [];
  let lineNum = 0;

  for await (const line of rl) {
    if (lineNum === 0) {
      headers = line.split(",").map(h => h.trim());
      console.log("📋 Colonnes détectées:", headers);
      lineNum++;
      continue;
    }

    // Analyse de la ligne CSV en gérant les virgules entre guillemets
    const values = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    const obj = {};
    headers.forEach((h, i) => {
      obj[h] = (values[i] || "").trim().replace(/^"|"$/g, "");
    });

    // Correspondance avec le schéma de la table Stages
    const row = {
      siret: obj.siret || null,
      nom: obj.nom || obj.enseigne1Etablissement || obj.denominationUsuelleEtablissement || "Sans nom",
      adresse: obj.adresse || null,
      ville: obj.libelleCommuneEtablissement || obj.ville || "PARIS",
      lat: parseFloat(obj.lat) || null,
      lng: parseFloat(obj.lng) || null,
      domaines: obj.domaines ? parseArray(obj.domaines) : null,
      score_embauche: obj.score_embauche ? parseFloat(obj.score_embauche) : null,
      source: obj.source || "import_csv",
      code_naf: obj.activitePrincipaleEtablissement || obj.code_naf || null,
      tranche_effectif: obj.trancheEffectifsEtablissement || obj.tranche_effectif || null,
    };

    // Exclusion des lignes sans coordonnées valides
    if (!row.lat || !row.lng || isNaN(row.lat) || isNaN(row.lng)) {
      continue;
    }

    rows.push(row);
    lineNum++;
  }

  console.log(`✅ ${rows.length} lignes valides à importer`);

  // Importation des données par lots (batch)
  let imported = 0;
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const { error } = await supabase
      .from("Stages")
      .upsert(batch, { onConflict: "siret", ignoreDuplicates: false });

    if (error) {
      console.error(`❌ Erreur batch ${i}-${i + BATCH_SIZE}:`, error.message);
    } else {
      imported += batch.length;
      console.log(`✅ ${imported}/${rows.length} importées...`);
    }
  }

  console.log(`\n🎉 Import terminé ! ${imported} entreprises dans Supabase.`);
}

importCSV().catch(console.error);
