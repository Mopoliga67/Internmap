import pandas as pd
import os

# --- CONFIGURATION ---
FILE_INPUT = 'StockEtablissement_utf8.csv'
FILE_OUTPUT = 'stages_pret_pour_supabase.csv'
CHUNK_SIZE = 100000  # On traite 100 000 lignes à la fois

# Colonnes à lire dans le fichier SIRENE (on ne prend que l'essentiel)
COLS_TO_LOAD = [
    'siret', 'codePostalEtablissement', 'libelleCommuneEtablissement',
    'etatAdministratifEtablissement', 'enseigne1Etablissement',
    'denominationUsuelleEtablissement', 'activitePrincipaleEtablissement',
    'trancheEffectifsEtablissement', 'numeroVoieEtablissement',
    'typeVoieEtablissement', 'libelleVoieEtablissement'
]

print(f"🚀 Début de l'extraction de {FILE_INPUT}...")

# Supprimer le fichier de sortie s'il existe déjà pour repartir à zéro
if os.path.exists(FILE_OUTPUT):
    os.remove(FILE_OUTPUT)

write_header = True
total_paris = 0

try:
    # Lecture par morceaux
    for i, chunk in enumerate(pd.read_csv(FILE_INPUT, chunksize=CHUNK_SIZE, low_memory=False, usecols=COLS_TO_LOAD)):
        
        # 1. Filtre : Paris (75) et Entreprises Actives ('A')
        chunk['codePostalEtablissement'] = chunk['codePostalEtablissement'].astype(str)
        mask = (chunk['codePostalEtablissement'].str.startswith('75')) & (chunk['etatAdministratifEtablissement'] == 'A')
        df_paris = chunk[mask].copy()

        if not df_paris.empty:
            # 2. Gestion du NOM (Priorité au nom commercial, sinon l'enseigne)
            df_paris['nom'] = df_paris['denominationUsuelleEtablissement'].fillna(df_paris['enseigne1Etablissement'])
            
            # SUPPRESSION des entreprises sans nom (très important pour ton problème)
            df_paris = df_paris.dropna(subset=['nom'])

            if not df_paris.empty:
                # 3. Création de l'ADRESSE complète
                df_paris['adresse'] = (
                    df_paris['numeroVoieEtablissement'].fillna('') + ' ' +
                    df_paris['typeVoieEtablissement'].fillna('') + ' ' +
                    df_paris['libelleVoieEtablissement'].fillna('')
                ).str.replace(r'\s+', ' ', regex=True).str.strip()

                # 4. Ajout des colonnes pour ton schéma Supabase
                df_paris['score_embauche'] = 0
                df_paris['domaines'] = '{}'
                df_paris['source'] = 'Sirene'
                df_paris['lat'] = 0.0
                df_paris['lng'] = 0.0
                
                # 5. Mapping des colonnes finales
                df_final = df_paris.rename(columns={
                    'activitePrincipaleEtablissement': 'code_naf',
                    'trancheEffectifsEtablissement': 'tranche_effectif',
                    'libelleCommuneEtablissement': 'ville'
                })

                # On ne garde que les colonnes de ta table "Stages"
                cols_to_save = [
                    'nom', 'adresse', 'ville', 'siret', 'lat', 'lng', 
                    'domaines', 'score_embauche', 'source', 'code_naf', 'tranche_effectif'
                ]
                
                # 6. Écriture (Mode Append)
                df_final[cols_to_save].to_csv(FILE_OUTPUT, mode='a', index=False, header=write_header)
                
                write_header = False
                total_paris += len(df_final)

        # Log de progression
        if (i + 1) % 10 == 0:
            print(f"⏳ Lignes lues : {(i + 1) * CHUNK_SIZE} | Entreprises Paris trouvées : {total_paris}")

    print(f"\n✅ TERMINÉ ! {total_paris} entreprises avec noms trouvées à Paris.")
    print(f"📁 Fichier créé : {FILE_OUTPUT}")

except Exception as e:
    print(f"💥 Erreur : {e}")