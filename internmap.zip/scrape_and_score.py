import os
import hashlib
import requests
from supabase import create_client, Client

# Initialisation Supabase
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY")
RAPIDAPI_KEY = os.environ.get("RAPIDAPI_KEY")

if not SUPABASE_URL or not SUPABASE_KEY or not RAPIDAPI_KEY:
    raise ValueError("Les variables d'environnement SUPABASE_URL, SUPABASE_KEY et RAPIDAPI_KEY doivent être définies.")

supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

def generate_hash(company_name, job_title):
    raw_string = f"{company_name}_{job_title}".lower().strip()
    return hashlib.sha256(raw_string.encode('utf-8')).hexdigest()

def fetch_jobs_from_jsearch():
    # Récupération des offres de stage à Paris
    url = "https://jsearch.p.rapidapi.com/search"
    querystring = {"query": "Stage Paris", "page": "1", "num_pages": "1"}
    headers = {
        "x-rapidapi-key": RAPIDAPI_KEY,
        "x-rapidapi-host": "jsearch.p.rapidapi.com"
    }
    print("Récupération des offres depuis JSearch...")
    response = requests.get(url, headers=headers, params=querystring)
    response.raise_for_status()
    return response.json().get('data', [])

def main():
    jobs = fetch_jobs_from_jsearch()
    if not jobs:
        print("Aucune offre trouvée.")
        return

    # Vérification des offres existantes
    print("Récupération des hashes existants depuis Supabase...")
    response = supabase.table('Offres_Traitees').select('id_offre_hash').execute()
    existing_hashes = {row['id_offre_hash'] for row in response.data}

    new_offers_to_insert = []
    companies_to_increment = []

    for job in jobs:
        company_name = job.get('employer_name')
        job_title = job.get('job_title')

        if not company_name or not job_title:
            continue

        job_hash = generate_hash(company_name, job_title)

        if job_hash not in existing_hashes:
            print(f"Nouvelle offre détectée : {job_title} chez {company_name}")

            # Recherche de l'entreprise correspondante
            search_res = supabase.table('Stages').select('nom, siret').ilike('nom', f"%{company_name}%").execute()

            siret = None
            if search_res.data and len(search_res.data) > 0:
                siret = search_res.data[0].get('siret')
                real_company_name = search_res.data[0].get('nom')
                companies_to_increment.append(real_company_name)
                print(f"Match trouvé dans la base : {real_company_name} (SIRET: {siret})")

            new_offers_to_insert.append({
                "id_offre_hash": job_hash,
                "siret_entreprise": siret
            })
            existing_hashes.add(job_hash)

    # Insertion des nouvelles offres
    if new_offers_to_insert:
        print(f"Insertion de {len(new_offers_to_insert)} nouvelles offres dans Supabase...")
        supabase.table('Offres_Traitees').insert(new_offers_to_insert).execute()
    else:
        print("Aucune nouvelle offre à insérer.")

    # Mise à jour des scores d'embauche
    unique_companies = list(set(companies_to_increment))
    if unique_companies:
        print(f"Incrémentation des scores pour {len(unique_companies)} entreprises...")
        supabase.rpc('bulk_increment_scores', {'company_names': unique_companies}).execute()
        print("Scores mis à jour avec succès.")

if __name__ == "__main__":
    main()
