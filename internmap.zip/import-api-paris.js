const { createClient } = require("@supabase/supabase-js");

// ⚠️ Remplace par ta SERVICE ROLE KEY
const SUPABASE_URL = "https://kykglnfuvxcfitpmugld.supabase.co";
const SUPABASE_SERVICE_KEY = "sb_secret_CiykQFkUbA522qtQu2rtXw_jJvAlSfl";
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// Codes postaux de Paris (75001 à 75020)
const CODES_POSTAUX_PARIS = Array.from({ length: 20 }, (_, i) =>
  `750${String(i + 1).padStart(2, "0")}`
);

// Mapping code NAF → domaines
const NAF_DOMAINES = {
  "62": ["informatique", "tech", "développement"],
  "63": ["informatique", "tech", "data"],
  "64": ["finance", "banque", "comptabilité"],
  "65": ["finance", "assurance"],
  "66": ["finance", "conseil"],
  "70": ["conseil", "management", "stratégie"],
  "69": ["droit", "juridique", "comptabilité"],
  "71": ["architecture", "ingénierie", "btp"],
  "73": ["marketing", "communication", "publicité"],
  "78": ["rh", "recrutement"],
  "74": ["conseil", "design"],
  "58": ["médias", "édition"],
  "59": ["médias", "audiovisuel", "communication"],
  "60": ["médias", "radio", "tv"],
  "46": ["commerce", "négoce"],
  "47": ["commerce", "retail", "vente"],
  "86": ["santé", "médical"],
  "85": ["enseignement", "formation"],
  "84": ["administration", "secteur public"],
  "41": ["btp", "immobilier", "construction"],
  "68": ["immobilier"],
  "49": ["logistique", "transport"],
  "52": ["logistique", "supply chain"],
};

function getDomainesFromNaf(codeNaf) {
  if (!codeNaf) return ["autre"];
  const prefix2 = codeNaf.substring(0, 2);
  return NAF_DOMAINES[prefix2] || ["autre"];
}

const TRANCHES_VALIDE = ['NN', '00', '01', '02', '03', '11', '12', '21', '22', '31', '32', '41'];

function getScoreEmbauche(tranche) {
  if (!tranche) return Math.floor(Math.random() * 4) + 1; // 1-4
  switch (tranche) {
    case 'NN':
    case '00':
    case '01': return 1 + Math.floor(Math.random() * 2); // 1-2
    case '02':
    case '03': return 3 + Math.floor(Math.random() * 2); // 3-4
    case '11':
    case '12': return 5 + Math.floor(Math.random() * 2); // 5-6
    case '21':
    case '22': return 7; // 7
    case '31':
    case '32': return 8; // 8
    case '41': return 9 + Math.floor(Math.random() * 2); // 9-10
    default: return 5;
  }
}

async function fetchEntreprisesByCodePostal(codePostal, page = 1) {
  const url = `https://recherche-entreprises.api.gouv.fr/search?code_postal=${codePostal}&per_page=25&page=${page}&statut_diffusion=O`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} pour ${codePostal}`);
  return res.json();
}

async function importParisData() {
  console.log("🗼 Début de l'import des entreprises parisiennes...\n");

  let totalImported = 0;

  for (const cp of CODES_POSTAUX_PARIS) {
    console.log(`📍 Traitement du code postal: ${cp}`);

    try {
      // Récupère plus de pages pour avoir au moins 800 entreprises supplémentaires (pages 3 à 8)
      for (let page = 3; page <= 8; page++) {
        const data = await fetchEntreprisesByCodePostal(cp, page);
        const results = data.results || [];

        if (results.length === 0) break;

        const rows = [];

        for (const entreprise of results) {
          // Prend le premier siège ou établissement disponible
          const siege = entreprise.siege || {};
          const lat = parseFloat(siege.latitude);
          const lng = parseFloat(siege.longitude);

          // Ignore si pas de coordonnées GPS
          if (!lat || !lng || isNaN(lat) || isNaN(lng)) continue;

          const codeNaf = siege.activite_principale || entreprise.activite_principale;
          const domaines = getDomainesFromNaf(codeNaf);
          
          const tranche = siege.tranche_effectif_salarie || entreprise.tranche_effectif_salarie;
          // Ignorer si l'entreprise a > 1000 employés
          if (tranche && !TRANCHES_VALIDE.includes(tranche)) {
            continue;
          }

          rows.push({
            siret: siege.siret || null,
            nom:
              entreprise.nom_complet ||
              entreprise.nom_raison_sociale ||
              "Entreprise sans nom",
            adresse: [
              siege.numero_voie,
              siege.type_voie,
              siege.libelle_voie,
              siege.code_postal,
              siege.libelle_commune,
            ]
              .filter(Boolean)
              .join(" "),
            ville: "PARIS",
            lat,
            lng,
            domaines,
            score_embauche: getScoreEmbauche(tranche),
            source: "API_Recherche_Entreprises",
            code_naf: codeNaf || null,
            tranche_effectif: tranche || null,
          });
        }

        if (rows.length === 0) continue;

        const { error } = await supabase
          .from("Stages")
          .upsert(rows, { onConflict: "siret", ignoreDuplicates: true });

        if (error) {
          console.error(`  ❌ Erreur Supabase: ${error.message}`);
        } else {
          totalImported += rows.length;
          console.log(`  ✅ Page ${page}: ${rows.length} entreprises ajoutées`);
        }

        // Pause pour respecter le rate limit de l'API (5 req/s max)
        await new Promise((r) => setTimeout(r, 250));
      }
    } catch (err) {
      console.error(`  ⚠️ Erreur sur ${cp}: ${err.message}`);
    }
  }

  console.log(`\n🎉 Import terminé ! ${totalImported} entreprises ajoutées au total.`);
}

importParisData().catch(console.error);
