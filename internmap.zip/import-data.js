const { createClient } = require("@supabase/supabase-js");
const axios = require("axios");

// 1. CONFIGURATION
const SUPABASE_URL = "https://kykglnfuvxcfitpmugld.supabase.co";
const SUPABASE_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imt5a2dsbmZ1dnhjZml0cG11Z2xkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY3MjA1NDAsImV4cCI6MjA5MjI5NjU0MH0.j2-zdNR7nglDLMebecY1vbpEKYS0jSy12F0GEWWpXcw";
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

const CLIENT_ID = process.env.FT_CLIENT_ID;
const CLIENT_SECRET = process.env.FT_CLIENT_SECRET;

if (!CLIENT_ID || !CLIENT_SECRET) {
  throw new Error(
    "Renseignez FT_CLIENT_ID et FT_CLIENT_SECRET dans l'environnement " +
      "(identifiants API France Travail)."
  );
}


const zones = [
  { ville: "Paris", lat: 48.8566, lng: 2.3522 },
  { ville: "Nanterre", lat: 48.892, lng: 2.206 },
  { ville: "Versailles", lat: 48.804, lng: 2.12 },
];

async function importer() {
  try {
    console.log("🔑 Demande de token...");

    // A. Récupération du Token avec Axios
    const tokenRes = await axios.post(
      "https://entreprise.francetravail.fr/connexion/oauth2/access_token?realm=%2Fpartenaire",
      `grant_type=client_credentials&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}&scope=api_labonneboitev2`,
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } },
    );

    const token = tokenRes.data.access_token;
    console.log("✅ Token obtenu !");

    for (const zone of zones) {
      console.log(`🔎 Scan de ${zone.ville}...`);

      // B. Requête Data
      try {
        const response = await axios.get(
          "https://api.francetravail.io/partenaire/labonneboite/v2/company",
          {
            params: {
              latitude: zone.lat,
              longitude: zone.lng,
              distance: 20,
              rome_codes: "M1805",
            },
            headers: {
              Authorization: `Bearer ${token}`,
              Accept: "application/json",
            },
          },
        );

        const companies = response.data.companies || [];

        if (companies.length > 0) {
          const batch = companies.map((c) => ({
            nom: c.name,
            adresse: c.address,
            lat: parseFloat(c.lat),
            lng: parseFloat(c.lon),
            type: "alternance",
            source: "API_LBB_V2",
            siret: c.siret,
          }));

          const { error } = await supabase
            .from("Stages")
            .upsert(batch, { onConflict: "siret" });
          if (error) console.error("❌ Supabase Error:", error.message);
          else
            console.log(
              `✅ ${batch.length} entreprises ajoutées pour ${zone.ville}`,
            );
        } else {
          console.log(`ℹ️ Aucun résultat pour ${zone.ville}`);
        }
      } catch (apiErr) {
        console.log(
          `⚠️ Erreur sur ${zone.ville}: Status ${apiErr.response?.status}`,
        );
        if (apiErr.response?.status === 403) {
          console.log(
            "Détail 403: Ton compte n'est pas encore autorisé pour cette API précise.",
          );
        }
      }

      // Pause pour éviter le ban
      await new Promise((r) => setTimeout(r, 1000));
    }
  } catch (err) {
    console.error("💥 Erreur fatale :");
    if (err.response) {
      console.error("Réponse du serveur :", err.response.data);
    } else {
      console.error(err.message);
    }
  }
}

importer();
