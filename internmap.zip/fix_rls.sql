-- ============================================
-- ÉTAPE 1 : Activer la lecture publique sur Stages
-- À coller dans : Supabase > SQL Editor > New query
-- ============================================

-- Option A : Désactiver le RLS complètement (le plus simple)
ALTER TABLE "Stages" DISABLE ROW LEVEL SECURITY;

-- ---- OU ---- (garder le RLS mais autoriser la lecture) ----

-- Option B : Ajouter une policy de lecture publique
-- ALTER TABLE "Stages" ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY "Lecture publique des stages"
--   ON "Stages"
--   FOR SELECT
--   USING (true);

-- ============================================
-- ÉTAPE 2 : Vérifier que la table a les bonnes colonnes
-- ============================================
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'Stages'
ORDER BY ordinal_position;

-- ============================================
-- ÉTAPE 3 : Voir les premières lignes
-- ============================================
SELECT nom, ville, lat, lng, domaines, score_embauche 
FROM "Stages" 
LIMIT 5;
