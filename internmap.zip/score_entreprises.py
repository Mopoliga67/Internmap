"""
Calcule une note d'embauche stagiaire/alternant pour chaque entreprise
et exporte un CSV trié par score décroissant.

Usage :
    set RAPIDAPI_KEY=...
    python score_entreprises.py

Sortie : Data/entreprises_notees.csv
"""

import csv
import os
import re
import sys
import time
import unicodedata
from difflib import SequenceMatcher

import requests

# --- CONFIG ---
INPUT_CSV = os.path.join("Data", "stages_pret_pour_supabase.csv")
OUTPUT_CSV = os.path.join("Data", "entreprises_notees.csv")
OUTPUT_SUPABASE_CSV = os.path.join("Data", "stages_avec_scores.csv")

RAPIDAPI_KEY = os.environ.get("RAPIDAPI_KEY")
JSEARCH_URL = "https://jsearch.p.rapidapi.com/search"
JSEARCH_HOST = "jsearch.p.rapidapi.com"

# Nombre de pages JSearch à récupérer par requête (10 résultats / page).
PAGES_PER_QUERY = 5
QUERIES = [
    ("Stage Paris", "stage"),
    ("Alternance Paris", "alternance"),
    ("Stagiaire Paris", "stage"),
    ("Apprentissage Paris", "alternance"),
]

# Pondération des offres
POIDS_STAGE = 2
POIDS_ALTERNANCE = 3

# Bonus selon tranche d'effectif INSEE (code -> bonus)
# https://www.insee.fr/fr/information/2028696
BONUS_TAILLE = {
    "00": 0, "01": 0, "02": 0, "03": 1, "11": 1, "12": 2,
    "21": 2, "22": 3, "31": 3, "32": 4, "41": 4, "42": 5,
    "51": 6, "52": 7, "53": 8,
}

# Secteurs (préfixe code NAF) connus pour recruter stages/alternance
BONUS_SECTEUR_NAF = {
    "62": 3,  # programmation, conseil informatique
    "63": 2,  # services d'information
    "70": 2,  # sièges sociaux, conseil de gestion
    "71": 2,  # ingénierie, études techniques
    "72": 3,  # R&D scientifique
    "73": 1,  # publicité, études de marché
    "74": 1,  # autres activités spécialisées
    "64": 2,  # services financiers
    "65": 1,  # assurance
    "66": 1,  # auxiliaires financiers
    "85": 1,  # enseignement
    "86": 1,  # santé humaine
    "58": 2,  # édition
    "59": 1,  # cinéma, musique
    "60": 1,  # programmation et diffusion
}

SEUIL_MATCH = 0.75  # similarité minimale pour matcher un nom (fuzzy)
SEUIL_TOKEN = 0.85  # similarité minimale en mode token-sort


# --- UTILITAIRES ---

def normalize(text: str) -> str:
    """Minuscule, sans accents, sans suffixes juridiques, espaces normalisés."""
    if not text:
        return ""
    text = unicodedata.normalize("NFD", text)
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    text = text.lower()
    # retire suffixes juridiques courants
    text = re.sub(
        r"\b(s\.?a\.?s\.?|s\.?a\.?|s\.?a\.?r\.?l\.?|sasu|eurl|sci|snc|gie|"
        r"groupe|holding|france|paris|france sa|sa france)\b",
        " ",
        text,
    )
    text = re.sub(r"[^a-z0-9 ]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def token_sort_ratio(a: str, b: str) -> float:
    """Compare en triant les tokens (gère l'ordre des mots et suffixes)."""
    ta = " ".join(sorted(a.split()))
    tb = " ".join(sorted(b.split()))
    return SequenceMatcher(None, ta, tb).ratio()


def best_match(offer_norm, norm_companies):
    """Retourne (company, score) ou (None, 0)."""
    if not offer_norm or len(offer_norm) < 3:
        return None, 0.0
    offer_tokens = set(offer_norm.split())

    best, best_score = None, 0.0
    for company, cnorm in norm_companies:
        if not cnorm:
            continue
        ctokens = set(cnorm.split())
        if not (offer_tokens & ctokens):
            continue

        # 1) Inclusion stricte (offer dans company ou inverse) -> match fort
        if offer_norm in cnorm or cnorm in offer_norm:
            score = 0.95
        else:
            # 2) Token sort + ratio classique, on prend le max
            score = max(similarity(offer_norm, cnorm),
                        token_sort_ratio(offer_norm, cnorm))

        if score > best_score:
            best, best_score = company, score
    return best, best_score


def bonus_taille(tranche) -> int:
    if tranche is None:
        return 0
    code = str(tranche).strip().zfill(2)
    return BONUS_TAILLE.get(code, 0)


def bonus_secteur(code_naf) -> int:
    if not code_naf:
        return 0
    prefix = str(code_naf).strip()[:2]
    return BONUS_SECTEUR_NAF.get(prefix, 0)


# --- RECUPERATION DES OFFRES ---

def fetch_offers():
    """Récupère toutes les offres pour toutes les requêtes/pages."""
    if not RAPIDAPI_KEY:
        print("[!] RAPIDAPI_KEY non definie - les offres ne seront pas recuperees.")
        print("    Le score sera calcule uniquement sur taille + secteur.")
        return []

    headers = {"x-rapidapi-key": RAPIDAPI_KEY, "x-rapidapi-host": JSEARCH_HOST}
    offers = []
    for query, kind in QUERIES:
        for page in range(1, PAGES_PER_QUERY + 1):
            params = {
                "query": query,
                "page": str(page),
                "num_pages": "1",
                "country": "fr",
                "language": "fr",
            }
            print(f"  -> JSearch [{query}] page {page}...")
            try:
                r = requests.get(JSEARCH_URL, headers=headers, params=params, timeout=30)
                r.raise_for_status()
                data = r.json().get("data", []) or []
            except Exception as e:
                print(f"    [!] Erreur : {e}")
                continue
            for o in data:
                employer = o.get("employer_name")
                if not employer:
                    continue
                title = (o.get("job_title") or "").lower()
                # affine le type via le titre si dispo
                offer_kind = kind
                if "alternance" in title or "apprenti" in title:
                    offer_kind = "alternance"
                elif "stage" in title or "stagiaire" in title:
                    offer_kind = "stage"
                offers.append({"employer": employer, "kind": offer_kind})
            time.sleep(0.4)  # politesse
    print(f"[OK] {len(offers)} offres recuperees.")
    return offers


# --- MATCHING + SCORING ---

def score_companies(companies, offers):
    # pré-normalise les noms d'entreprises
    norm_companies = [(c, normalize(c["nom"])) for c in companies]

    # compteurs
    for c in companies:
        c["nb_stages"] = 0
        c["nb_alternances"] = 0

    matched = 0
    for offer in offers:
        offer_norm = normalize(offer["employer"])
        best, score = best_match(offer_norm, norm_companies)
        if best and score >= SEUIL_MATCH:
            if offer["kind"] == "alternance":
                best["nb_alternances"] += 1
            else:
                best["nb_stages"] += 1
            matched += 1
    print(f"  -> {matched}/{len(offers)} offres matchees a une entreprise du CSV.")

    # calcule le score
    for c in companies:
        bt = bonus_taille(c.get("tranche_effectif"))
        bs = bonus_secteur(c.get("code_naf"))
        score = (
            c["nb_stages"] * POIDS_STAGE
            + c["nb_alternances"] * POIDS_ALTERNANCE
            + bt
            + bs
        )
        c["bonus_taille"] = bt
        c["bonus_secteur"] = bs
        c["score_total"] = score

    # note sur 5 normalisée par rapport au score max
    max_score = max((c["score_total"] for c in companies), default=0) or 1
    for c in companies:
        c["note_sur_5"] = round((c["score_total"] / max_score) * 5, 2)


# --- I/O ---

def load_companies(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_output(path, companies):
    cols = [
        "nom", "siret", "adresse", "ville",
        "code_naf", "tranche_effectif",
        "nb_stages", "nb_alternances",
        "bonus_taille", "bonus_secteur",
        "score_total", "note_sur_5",
    ]
    companies = sorted(companies, key=lambda c: c["score_total"], reverse=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(companies)


def write_supabase_csv(path, companies):
    """CSV au format de la table Supabase 'Stages' avec score_embauche rempli."""
    cols = [
        "nom", "adresse", "ville", "siret", "lat", "lng",
        "domaines", "score_embauche", "source",
        "code_naf", "tranche_effectif",
    ]
    rows = []
    for c in companies:
        rows.append({
            "nom": c.get("nom", ""),
            "adresse": c.get("adresse", ""),
            "ville": c.get("ville", ""),
            "siret": c.get("siret", ""),
            "lat": c.get("lat", ""),
            "lng": c.get("lng", ""),
            "domaines": c.get("domaines", "[]"),
            "score_embauche": int(c.get("score_total", 0)),
            "source": c.get("source", "Sirene"),
            "code_naf": c.get("code_naf", ""),
            "tranche_effectif": c.get("tranche_effectif", ""),
        })
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def main():
    if not os.path.exists(INPUT_CSV):
        print(f"[X] Fichier introuvable : {INPUT_CSV}")
        sys.exit(1)

    print(f"[1/4] Lecture de {INPUT_CSV}...")
    companies = load_companies(INPUT_CSV)
    print(f"  -> {len(companies)} entreprises chargees.")

    print("[2/4] Recuperation des offres...")
    offers = fetch_offers()

    print("[3/4] Calcul des scores...")
    score_companies(companies, offers)

    print(f"[4/4] Ecriture de {OUTPUT_CSV}...")
    write_output(OUTPUT_CSV, companies)
    print(f"       et de {OUTPUT_SUPABASE_CSV} (format table Stages)...")
    write_supabase_csv(OUTPUT_SUPABASE_CSV, companies)

    top = sorted(companies, key=lambda c: c["score_total"], reverse=True)[:10]
    print("\nTop 10 :")
    for c in top:
        print(
            f"  {c['note_sur_5']:>4}/5  ({c['score_total']:>3} pts)  "
            f"{c['nb_stages']}st / {c['nb_alternances']}alt  -  {c['nom']}"
        )
    print("\n[OK] Termine.")


if __name__ == "__main__":
    main()
