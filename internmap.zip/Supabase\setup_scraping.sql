-- Création de la table Offres_Traitees
CREATE TABLE IF NOT EXISTS public."Offres_Traitees" (
    id_offre_hash TEXT PRIMARY KEY,
    siret_entreprise TEXT,
    date_decouverte TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now())
);

-- Activation de RLS (Row Level Security) sur la nouvelle table
ALTER TABLE public."Offres_Traitees" ENABLE ROW LEVEL SECURITY;

-- Création des politiques pour permettre les accès (à restreindre en production si nécessaire)
CREATE POLICY "Allow read access for all users" ON public."Offres_Traitees" FOR SELECT USING (true);
CREATE POLICY "Allow insert access for all users" ON public."Offres_Traitees" FOR INSERT WITH CHECK (true);

-- Fonction pour incrémenter le score_embauche en masse
CREATE OR REPLACE FUNCTION bulk_increment_scores(company_names TEXT[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Met à jour le score_embauche de +1 pour les entreprises dont le nom est dans le tableau
    UPDATE public."Stages"
    SET score_embauche = score_embauche + 1
    WHERE nom = ANY(company_names);
END;
$$;
